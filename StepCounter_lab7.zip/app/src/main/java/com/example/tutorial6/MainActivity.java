package com.example.tutorial6;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentManager;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class MainActivity extends AppCompatActivity implements FragmentManager.OnBackStackChangedListener {
    private static final String TAG = "MainActivity";
    private static final int PERMISSION_REQUEST_CODE = 123;
    private static final long PERMISSION_RETRY_DELAY = 5000; // 5 seconds

    private final Handler handler = new Handler(Looper.getMainLooper());

    private boolean isRequestingPermissions = false;

    private String[] getRequiredPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) { // Android 12 and above
            return new String[]{
                    Manifest.permission.BLUETOOTH_CONNECT,
                    Manifest.permission.BLUETOOTH_SCAN
            };
        } else {
            return new String[]{
                    Manifest.permission.BLUETOOTH,
                    Manifest.permission.BLUETOOTH_ADMIN
            };
        }
    }

    private void checkAndRequestPermissions() {
        if (isRequestingPermissions) {
            return;
        }

        String[] permissions = getRequiredPermissions();
        boolean allPermissionsGranted = true;

        for (String permission : permissions) {
            if (ContextCompat.checkSelfPermission(this, permission)
                    != PackageManager.PERMISSION_GRANTED) {
                allPermissionsGranted = false;
                Log.w(TAG, "Missing permission: " + permission);
            }
        }

        if (allPermissionsGranted) {
            Log.i(TAG, "All permissions granted");
            initializeApp();
        } else {
            Log.w(TAG, "Requesting permissions");
            isRequestingPermissions = true;
            ActivityCompat.requestPermissions(this, permissions, PERMISSION_REQUEST_CODE);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportFragmentManager().addOnBackStackChangedListener(this);

        checkAndRequestPermissions();
    }


    private void schedulePermissionRetry() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!isFinishing()) {
                    isRequestingPermissions = false;
                    Log.i(TAG, "Retrying permission check after delay");
                    Toast.makeText(MainActivity.this,
                            "Please grant required permissions in Settings",
                            Toast.LENGTH_LONG).show();
                    checkAndRequestPermissions();
                }
            }
        }, PERMISSION_RETRY_DELAY);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        isRequestingPermissions = false;

        if (requestCode == PERMISSION_REQUEST_CODE) {
            boolean allGranted = true;
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    allGranted = false;
                    break;
                }
            }

            if (allGranted) {
                Log.i(TAG, "All permissions granted in result");
                initializeApp();
            } else {
                Log.w(TAG, "Permissions denied");
                Toast.makeText(this,
                        "Bluetooth permissions are required for this app to function",
                        Toast.LENGTH_LONG).show();

                // Schedule retry only if permissions are still needed
                handler.postDelayed(this::checkAndRequestPermissions, PERMISSION_RETRY_DELAY);
            }
        }
    }

    private void initializeApp() {
        Log.i(TAG, "Initializing app");
        if (getSupportFragmentManager().findFragmentByTag("devices") == null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .add(R.id.fragment, new DevicesFragment(), "devices")
                    .commit();
        } else {
            onBackStackChanged();
        }
    }

    @Override
    public void onBackStackChanged() {
        getSupportActionBar().setDisplayHomeAsUpEnabled(
                getSupportFragmentManager().getBackStackEntryCount() > 0
        );
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacksAndMessages(null);
    }
}